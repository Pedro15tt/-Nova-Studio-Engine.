# Nova Studio Engine

**Nova Studio Engine** é uma aplicação experimental de criação 3D no navegador. A interface organiza o fluxo de trabalho em projetos, viewport, Explorer e propriedades, com foco em uso mobile e desktop.

> **Estado do projeto:** protótipo funcional em desenvolvimento. Não é uma engine completa e não é uma cópia do Roblox Studio.

## O que já funciona nesta versão

- Tela inicial com perfil local (sem autenticação de conta)
- Hub para criar, abrir e listar projetos
- Viewport 3D com Three.js
- Câmera orbital e zoom
- Grade e iluminação básica
- Criar, selecionar e excluir cubos
- Ferramentas de mover, rotacionar e escalar
- Inspetor básico de nome, transformação, cor e visibilidade
- Salvamento e restauração de cenas no `localStorage` do navegador
- Modo de teste apenas visual (não executa um jogo independente)

## Ainda não implementado

- Login real, contas e sincronização em nuvem
- Importação/exportação de projetos e modelos
- Undo/Redo
- Runtime isolado para executar jogos
- Editor de scripts com execução segura
- Física, animação, áudio, terreno e biblioteca avançada de assets

## Abrir localmente

A aplicação usa módulos JavaScript e importa Three.js por CDN. Abra por um servidor HTTP local; abrir `index.html` diretamente como `file://` pode bloquear os módulos.

## Publicar no GitHub Pages

O repositório inclui um workflow em `.github/workflows/deploy.yml` para publicar o site automaticamente.

1. Crie um repositório público chamado **`Nova-Studio-Engine.GitHub`**.
2. Envie o conteúdo desta pasta para a **raiz** do repositório (o `index.html` deve ficar na raiz, não dentro de uma subpasta).
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment → Source**, selecione **GitHub Actions**.
5. Aguarde a execução do workflow **Deploy to GitHub Pages** na aba **Actions**.

Depois da primeira publicação, novos commits na branch `main` serão publicados automaticamente. A URL de projeto esperada é:

`https://pedro15tt.github.io/Nova-Studio-Engine.GitHub/`

## Estrutura

```text
.
├── .github/
│   └── workflows/
│       └── deploy.yml
├── .nojekyll
├── index.html
├── README.md
├── LICENSE
└── src/
    ├── main.js
    ├── studio.js
    ├── scene-editor.js
    └── styles.css
```

## Observações técnicas

- Projetos e perfil são guardados no `localStorage`: ficam neste navegador/dispositivo e não sincronizam com outros aparelhos.
- O nome de perfil é apenas uma identificação local. Não use senhas ou dados sensíveis.
- Three.js é carregado por CDN; é necessária conexão com a internet para inicializar o editor.
- O modo **Testar** atual altera o estado visual do editor e registra uma mensagem; não inicia um runtime de jogo.
- O protótipo ainda precisa de testes em navegadores e dispositivos móveis reais antes de ser considerado estável.

## Licença

MIT — consulte `LICENSE`.
